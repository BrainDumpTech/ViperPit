﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class SHOPHealth
    Inherits System.Web.UI.Page

    Dim m_strConnString As String
    Dim m_SqlConn As SqlConnection


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Dim strSQL As String



        m_strConnString = System.Configuration.ConfigurationManager.AppSettings("SHOPDB").ToString
        SqlSHOPHealthMgmt.ConnectionString = m_strConnString
        SqlSHOPHealthProd.ConnectionString = m_strConnString
        m_SqlConn = New SqlConnection(m_strConnString)
        m_SqlConn.Open()

        SqlSHOPHealthMgmt.SelectCommand = "select monitor, monitordesc, lastupdate, case status when '1' then '~/images/ok.gif' else '~/images/failed.gif' end as PictureURL  from shophealth"
        SqlSHOPHealthProd.SelectCommand = "select monitor, monitordesc, lastupdate, case status when '1' then '~/images/ok.gif' else '~/images/failed.gif' end as PictureURL  from shophealth"

    End Sub
End Class
