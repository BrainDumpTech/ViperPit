﻿
Partial Class FISPortal
    Inherits System.Web.UI.MasterPage

   
    
End Class

